#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo how to open/close and read, write
# randomly to a file using the .seek() and .tell() methods.
"""
    DocString:
"""
SOF = 0 # Start of File
CUR = 1 # Current position
EOF = 2 # End of file


# Open file handle in READING in text mode!
with open(r"c:\labs\projects\Sky_data_Sep_23\movies.txt", mode="rt") as fh_in:
    fh_in.seek(90, SOF) # Seek forwards 90 chars from SOF.
    text = fh_in.read(30)
    print(f"Text at {fh_in.tell() - len(text)} = {text}")

    fh_in.seek(135, SOF) # Seek forwards 135 chars from SOF.
    text = fh_in.read(30)
    print(f"Text at {fh_in.tell() - len(text)} = {text}")

# Open file handle for READING in binary/bytes mode!
with open(r"c:\labs\projects\Sky_data_Sep_23\movies.txt", mode="rb") as fh_in:
    fh_in.seek(-120, EOF) # Seek backwards 120 bytes from EOF.
    text = fh_in.read(30)
    print(f"Text at {fh_in.tell() - len(text)} = {text}")

    fh_in.seek(-60, CUR) # Seek backwards 60 bytes from current position.
    text = fh_in.read(30)
    print(f"Text at {fh_in.tell() - len(text)} = {text}")