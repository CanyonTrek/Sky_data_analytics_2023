#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program 
"""
    DocString:
"""

fh_in = open(r"c:\labs\top_250.txt", mode="rt")

for line in fh_in:
    print(line, end="")

fh_in.close()