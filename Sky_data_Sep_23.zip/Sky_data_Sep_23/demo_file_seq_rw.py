#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo how to open/close, read, write and
# append to a text file using the built-in open function.
"""
    DocString:
"""
import sys
# Dict of lists of strings.
movies = {'jess': ['miss congeniality', 'lion king', 'the incredibles'],
          'Kaitlin': ['clueless', 'mean girls', 'lego movie'],
          'colette': ['the pianist', 'rush', 'dark knight'],
          'donald': ['lotr', 'life or brian', 'holy grail']
}

# Open file handle for WRITING in TEXT mode!
fh_out = open(r"c:\labs\projects\Sky_data_Sep_23\movies.txt", mode="wt")

# ITERATE through dict keys and write keys+objects to file handle
# using an ITERATOR for loop.
for name in movies.keys():
    print(f"{name}: {movies[name]}", end="\n", file=sys.stdout)
    print(f"{name}: {movies[name]}", end="\n", file=fh_out)
    # fh_out.write(f"{name}: {movies[name]}\n")

# fh_out.flush() # Flush buffer.
fh_out.close() # Flush buffers and close file handle!

print("-" * 60)
# Open file handle for READING in TEXT mode!
fh_in = open(r"c:\labs\projects\Sky_data_Sep_23\movies.txt", mode="rt")

# text = fh_in.read() # Read ENTIRE file into a str object! Be Careful!
# text = fh_in.read(30) # Read NEXT 30 chars into a str object!
# text = fh_in.readline() # Read NEXT LINE into a str object!
# lines = fh_in.readlines() # Read ENTIRE file into a LIST object! Be Careful!
# print(lines[-1]) # Do LIST indexing to choose any line! Useful!

# ITERATE through the file-handle (ITERATOR object = next()/iter() )
# one line at a time using an iterator for loop.
# for line in open(r"c:\labs\projects\Sky_data_Sep_23\movies.txt", mode="rt"):
for line in fh_in:
    print(line, end="")

fh_in.close()