#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo how to match and make
# a substitution using Regex and the re.sub() function.
"""
    DocString:
"""
import re

# Sample from /etc/passwd on Linux for the root user login.
line = "root:x:0:0:The Super User:/root:/bin/ksh\n"

line = re.sub(r"[Ss]uper [Uu]ser", r"Administrator", line) # Returns Modified str.
line = re.sub(r"ksh$", r"bash", line) # Returns Modified TUPLE (str,num of changes)
(line, num) = re.subn(r"root", r"groot", line) # Returns Modified TUPLE (str,num of changes)

print(f"New line={line.rstrip()}, modified {num} times")