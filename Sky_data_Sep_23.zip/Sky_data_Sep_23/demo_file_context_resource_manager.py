#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo how to open/close, read, write and
# append to a text file and automatically close the file handle using
# a context resource manager (with statement= emulate block scope)
"""
    Safer way to manage resources like file handles
"""
# Dict of lists of strings.
movies = {'jess': ['miss congeniality', 'lion king', 'the incredibles'],
          'Kaitlin': ['clueless', 'mean girls', 'lego movie'],
          'colette': ['the pianist', 'rush', 'dark knight'],
          'donald': ['lotr', 'life or brian', 'holy grail']
}

with open(r"c:\labs\projects\Sky_data_Sep_23\movies.txt", mode="wt") as fh_out:
    for name in movies.keys():
        print(f"{name}: {movies[name]}", end="\n")
        fh_out.write(f"{name}: {movies[name]}\n")

print("-" * 60)

with open(r"c:\labs\projects\Sky_data_Sep_23\movies.txt", mode="rt") as fh_in:
    for line in fh_in:
        print(line, end="")

