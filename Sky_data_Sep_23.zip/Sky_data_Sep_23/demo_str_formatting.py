#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo different ways of formatting strings.
"""
    DocString:
"""
# Create a dict of planet info: names + distance to sun in Giga-metres.
planets = {'Mercury': 57.91,
           'Venus': 108.2,
           'Earth': 149.597870,
           'Mars': 227.94
}

# ITERATE through planets and display planet info
# using str concatenation + escape chars - UGLY!
for planet in planets:
    print("\t\t" + planet + ": " + str(planets[planet]) + " Gm " + str(hex(0xff)))

print("-" * 40)

# using str justification methods + concatenation - OK!
for planet in planets:
    print(planet.rjust(12) + ": " + str(planets[planet]).center(12, '.') + " Gm " +
          str(hex(0xff)).rjust(6))

print("-" * 40)
# using str .format() method - GOOD!
for planet in planets:
    print("{0:>12s}: {1:.^12.3f} Gm {2:>#6x}".format(planet, planets[planet], 0xff))

print("-" * 40)
# using f-strings, introduced from Py 3.5 onwards - BEST!
for planet in planets:
    print(f"{planet:>12s}: {planets[planet]:.^12.3f} Gm {0xff:>#6x}")

print("-" * 40)
# Python 2 way of formatting strings! Use f-strings instead!
for planet in planets:
    print("%12s: %12.3f Gm %#6x" % (planet, planets[planet], 0xff))