#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo a user function with parameter passing.
"""
    A Script to search for Regex Patterns in a file.
"""
import sys
import re

# Example of USEFUL user function with parameter passing and
# default values, and annotations.
def search_pattern(pattern:str=r"^([A-Z]).*\1$", file:str=r"c:\labs\words")->None:
    """ Search for Regex pattern in a file """
    # OPen file handle for READING in TEXT mode!
    with open(file, mode="rt") as fh_in:
        for line in fh_in:
            m = re.search(pattern, line) # Match lines with 5 char palindromes!
            if m:
                print(f"Matched {m.group()} on {line.rstrip()} at pos {m.start()}-{m.end()}")
    return None

# Example of a VARIADIC function, which accepts variable number
# or parameters into a TUPLE!
def search_files(pattern, *files):
    """ Search for Regex pattern in multiple files """
    lines = 0
    for file in files:
        with open(file, mode="rt") as fh_in:
            for line in fh_in:
                m = re.search(pattern, line) # Match lines with 5 char palindromes!
                if m:
                    lines += 1
                    print(f"Matched {m.group()} on {line.rstrip()} at pos {m.start()}-{m.end()}")
    return lines


def main():
    search_pattern(r"^.{19}$", r"c:\labs\words")
    num = search_files(r"^.{28}$", r"c:\labs\words", r"c:\labs\words2", r"c:\labs\words3")
    print(f"Matched {num} lines")
    return None

# Namespace Trick.
if __name__ == "__main__":
    # Execute only if ran directly as a program.
    # Ignore if imported as a module
    main()
    sys.exit(0)