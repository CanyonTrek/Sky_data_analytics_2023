#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will display the entire Unicode
# charset.
"""
    DocString:
"""

# ITERATE through all the char positions in the unicode table (0-65536)
for pos in range(0, 65536):
    try:
        print(chr(pos), end=" ")
        if pos % 16 == 0:
            print("")
    except UnicodeEncodeError:
        print(" ")