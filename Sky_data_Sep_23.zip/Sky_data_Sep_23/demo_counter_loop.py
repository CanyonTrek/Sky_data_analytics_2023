#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo how to REPEAT a block
# of commands a specific number of times using a COUNTER loop.
"""
    DocString:
"""

count = 0 # 1.Initialise counter.
while count < 10: # 2.Test counter.
    print(count)
    count += 1 # 3.Increment counter.

# Alternatively we can iterate through a sequence of
# numbers using a for loop plus the built-in
# range(start, stop, step) function.
for num in range(0, 10, 1):
    print(num)

# range(start, stop, step=1) function.
for num in range(0, 10):
    print(num)

# range(start=0, stop, step=1) function.
for num in range(10):
    print(num)