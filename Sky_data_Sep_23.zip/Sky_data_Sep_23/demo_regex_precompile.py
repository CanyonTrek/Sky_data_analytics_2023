#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo how to match string data using str testing
# and PATTERN matching using re.py module and Regex patterns.
"""
    DocString:
"""
import re
# OPen file handle for READING in TEXT mode!
fh_in = open(r"C:\labs\words", mode="rt")

reobj = re.compile(r"^([A-Z]).*\1$") # Pre-compile PATTERN JUST ONCE!

# Iterate through file handle (ITERATOR) one line a time.
for line in fh_in:
    # m = re.search(r"^([A-Z]).*\1$", line) # Re-compile PATTERN for every line! OUCH!
    m = reobj.search(line)
    if m:
        print(line, end="")

fh_in.close()