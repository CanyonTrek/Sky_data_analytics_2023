#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo how to create, grow, shrink and
# combine sets (Unordered Mutable Collections) using SET operators
# (Remember VENN diagrams).NO DUPLICATES!
"""
    DocString:
"""
# Create two SETS.
marvel_fans = {'holly', 'jess', 'sam', 'shazzad', 'donald', 'colette'}
dc_fans = set() # Create an empty set!

# Grow a set!
dc_fans.add('donald')
dc_fans.add('seonaid')
dc_fans.add('valle')

# dc_fans.pop() # Randomly remove an object
# comic_fans = dc_fans.copy() # Copy set.
# comic_fans.clear() # Empty set.

print(f"Fans of Marvel = {marvel_fans}")
print(f"Fans of DC = {dc_fans}")

print("-" * 60)

# Combine SETS using SET Methods.
print(f"Fans of either Marvel OR DC = {marvel_fans.union(dc_fans)}")
print(f"Fans of both Marvel AND DC = {marvel_fans.intersection(dc_fans)}")
print(f"Fans of only Marvel = {marvel_fans.difference(dc_fans)}")
print(f"Fans of only Marvel OR DC = {marvel_fans.symmetric_difference(dc_fans)}")
print("=" * 60)
# Combine SETS using SET Operators.
print(f"Fans of either Marvel OR DC = {marvel_fans | dc_fans}")
print(f"Fans of both Marvel AND DC = {marvel_fans & dc_fans}")
print(f"Fans of only Marvel = {marvel_fans - dc_fans}")
print(f"Fans of only Marvel OR DC = {marvel_fans ^ dc_fans}")