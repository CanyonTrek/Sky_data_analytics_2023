#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This is an ultr realistic computer game with Tanks!
"""
    GOT - Game of Tanks!
"""

import tank

# Instantiate/create 3 Tank objects!
jess_tank = tank.Tank('German', 'Tiger')
sam_tank = tank.Tank('American', 'Sherman')
leah_tank = tank.Tank('British', 'Churchill')

# and the game begins..
jess_tank.accel(63)
sam_tank.accel(39)

leah_tank.rotate_left(289)
leah_tank.accel(29)
leah_tank.shoot()

# and success!
jess_tank.take_damage(71)
sam_tank.take_damage(43)

# And now for some game visuals! Or at least a print statement or two!
# print(f"Health of Jess's Tank is {jess_tank._health}") # POOR CODE!

# Example of Operator overloading.
print(f"Health of Jess's and Sam's Tanks = {jess_tank + sam_tank}")

# Example of Duck Typing, Our Tank can now Quack like a duck!
print(f"Status of Jess's tank is {jess_tank}")


# Jess has received a health boost!
jess_tank.set_health(101) # Example of a Setter method!
print(f"Jess's Tanks new health = {jess_tank.get_health()}")

# Jess has received a health boost!
jess_tank.tank_health = 102 # Example of a Setter method!
print(f"Jess's Tanks new health = {jess_tank.tank_health}")
print("Game Ends. Times up!")