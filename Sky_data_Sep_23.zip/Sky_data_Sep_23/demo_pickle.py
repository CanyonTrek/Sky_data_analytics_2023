#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo how to PRESERVE 1 x Python object
# (Data + Structure) to a pickle file using the pickle module.
"""
    DocString:
"""
import pickle
import pprint
import gzip # Others = gzip,bz2,tarfile,shutil
movies = {'jess': ['miss congeniality', 'lion king', 'the incredibles'],
          'Kaitlin': ['clueless', 'mean girls', 'lego movie'],
          'colette': ['the pianist', 'rush', 'dark knight'],
          'donald': ['lotr', 'life or brian', 'holy grail']
}

# Open file handle for WRITING in Bytes mode to a pickle file.
# with open(r"c:\labs\projects\Sky_data_Sep_23\movies.p", mode="wb") as fh_out:
with gzip.open(r"c:\labs\projects\Sky_data_Sep_23\movies.pgz", mode="wb") as fh_out:
    # pickle.dump(movies, fh_out, protocol=5) # Pickle protocols 0=ASCII 1-5=Binary
    pickle.dump(movies, fh_out, pickle.DEFAULT_PROTOCOL)  # Pickle = 4
    # pickle.dump(movies, fh_out, pickle.HIGHEST_PROTOCOL)  # Pickle = 5

# Open file handle for READING in Bytes mode to a pickle file.
# with open(r"c:\labs\projects\Sky_data_Sep_23\movies.p", mode="rb") as fh_in:
with gzip.open(r"c:\labs\projects\Sky_data_Sep_23\movies.pgz", mode="rb") as fh_in:
    films = pickle.load(fh_in)

pprint.pprint(movies)
print("-" * 60)
pprint.pprint(films)
