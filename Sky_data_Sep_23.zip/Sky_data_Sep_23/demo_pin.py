#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will emulate an ATM bank machine
# with PIN entry.
"""
    DocString:
"""

master_pin = "0123"
pin = None
attempts = 0

while pin != master_pin and attempts < 3:
    pin = input("Enter PIN: ")
    if pin == master_pin:
        print("Valid PIN")
        break
    else:
        print("Invalid PIN")
        attempts += 1
else:
    # Execute ONCE when loop condition becomes False.
    print("Too many attempts")
    print("Your card has been retained. Have a nice day!")


print("Done")