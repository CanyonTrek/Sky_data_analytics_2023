#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo how to create, grow and shrink
# dict (Unordered Mutable COllections with Unique Keys). From Py3.6 onwards
# dict are in INSERTION order.
"""
    DocString:
"""
import pprint

# A multi-dimensional dict of lists!
movies = {'jess': ['miss congeniality', 'lion king', 'the incredibles'],
          'Kaitlin': ['clueless', 'mean girls', 'lego movie'],
          'colette': ['the pianist', 'rush', 'dark knight']
}
# Add new key+objects to dict.
movies['donald'] = ['lotr', 'life or brian', 'holy grail']
pprint.pprint(movies)
print("-" * 60)

print(f"Collete's favourite movies = {movies['colette']}")
print(f"Collete's favourite movies = {movies.get('colette')}")
print(f"Collete's ultimate movie = {movies['colette'][0]}")

# films = movies.copy() # Copy dict.
# films.clear() # Empty dict.
# movies.pop('donald') # Remove key+object by name.
# movies.popitem() # Removes last inserted object.

# Iterate through keys, values and both using an ITERATOR for loop.
# Iterate through keys.
for name in movies.keys():
    print(f"{name} likes {movies[name]}")

print("-" * 60)
# Iterate through values.
for films in movies.values():
    print(f"{films}")

print("-" * 60)
# Iterate through keys+values.
for name, films in movies.items():
    print(f"{name} loves {films}")


