#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo how to define, name, and call
# a user function, optionally passing parameters and returning data.
"""
    DocString:
"""
# Example of a user function with parameter passing and default values.
# Annotations - embedded comment used to describe preferred type for
# parameters (Not enforced).
def say_hello(greeting:str="hallo", recipient:str="meine freunde")->None:
    message = f"{greeting} {recipient}"
    print(message)
    return None


say_hello("hola", "mis amgos") # Positional parameter passing.
say_hello(greeting="bonjour", recipient="mes amis") # Named parameter passing.
say_hello(recipient="chingudeul", greeting="annyeonghaseyo") # Named parameter (in any order)
say_hello("konichiwa", recipient="tomodachi") # Mixed parameter passing (positional->named)
say_hello("hallo", "mein fruende")
say_hello()

# Can find out what anotations a user function uses!
print(f"Annotations for say_hello is {say_hello.__annotations__}")
