#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo how to ITERATE through a collection
# (str/tuple/list/dict/set) using an ITERATOR for loop.
"""
    DocString:
"""
#              0              1              2             3..
heroes = ['rosa parks', 'marie curie', 'jane austen', 'ada lovelace', 'florence nightingale']

# ITERATE through the list object at a time using an
# ITERATOR for loop.
for name in heroes:
    print(name, end="\n")
print("Heroes=", heroes)

# ITERATE through the collection and MODIFY the objects using
# an ITERATOR for loop plus and index.
idx = 0
for name in heroes:
    print(name.title(), end="\n")
    heroes[idx] = name.title()
    idx += 1
print("Modified Heroes=", heroes)

# ITERATE through the collection and MODIFY the objects using
# an ITERATOR for loop plus and built-in enumerate() function.
for (idx, name) in enumerate(heroes, start=0):
    print(name.upper(), end="\n")
    heroes[idx] = name.upper()
print("Modified Heroes=", heroes)