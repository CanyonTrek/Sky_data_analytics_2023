#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo how to ITERATE through separate
# but index-related collections using an ITERATOR for loop plus the
# built-in zip() function.
"""
    DocString:
"""
# Create 4 separate but index-related lists.
grads = ['holly', 'seonaid', 'joseph']
fav_bands = ['coldplay', 'fleetwood mac', 'the cure']
fav_heroes = ['jane austen', 'serena williams', 'mo salah']
fav_locs = ['thailand', 'italy', 'kent']

# Iterate through all the separate but index-related lists
# and link all the same indexes together using an ITERATOR for
# loop plus the built-in zip() function.
for (g, fb, fh, fl) in zip(grads, fav_bands, fav_heroes, fav_locs):
    print(g + " likes to listen to " + fb + " with " + fh + " in " + fl)

name = "Donald"
name.