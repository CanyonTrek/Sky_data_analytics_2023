#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo how to split and rejoin strings
# using the .split() and .join() str methods.
"""
    DocString:
"""

# Sample from /etc/passwd on Linux for the root user login.
line = "root:x:0:0:The Super User:/root:/bin/ksh\n"
# But I want to make changes to the string (immutable=ReadOnly!)

fields = line.split(":") # Returns a list (mutable) of objects.
fields[4] = "The Administrator"
fields[6] = "/bin/bash"
line = ":".join(fields) # Returns a str.
print("Modified str=", line)