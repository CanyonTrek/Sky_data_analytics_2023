#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will generate 6 unique
# random lottery numbers.
"""
    DocString:
"""
import random
import sys

# lotto = [] # Create empty list.

# while len(lotto) < 6:
#    num = random.randint(1, 50)
#    if num not in lotto:
#        lotto.append(num)
#    else:
#        print("Duplicate number=", num)

# A PYTHONIC solution as it uses Python features which
# other languages don't have!
lotto = set() # Create an empty set

while len(lotto) < 6:
    num = random.randint(1, 50)
    lotto.add(num)

print("lottery numbers =", sorted(lotto))

# sys.exit("Goodbye") # Exit program and send str to STDERR, exit code=1
try:
    # sys.exit() generates a SystemExit exeption which can be trapped.
    sys.exit(0) # Exit program with error code (0=success, 1-225=error)
except SystemExit:
    print("Ending Program...")
    sys.exit(100)